declare module 'router_js/lib/transition-intent/named-transition-intent' {
    import type { Dict } from "router_js/lib/core";
    import type { ModelFor, Route } from "router_js/lib/route-info";
    import type InternalRouteInfo from "router_js/lib/route-info";
    import { UnresolvedRouteInfoByObject, UnresolvedRouteInfoByParam } from "router_js/lib/route-info";
    import type { ParsedHandler } from "router_js/lib/router";
    import type Router from "router_js/lib/router";
    import { TransitionIntent } from "router_js/lib/transition-intent";
    import TransitionState from "router_js/lib/transition-state";
    export default class NamedTransitionIntent<R extends Route> extends TransitionIntent<R> {
        name: string;
        pivotHandler?: Route;
        contexts: ModelFor<R>[];
        queryParams: Dict<unknown>;
        preTransitionState?: TransitionState<R>;
        constructor(router: Router<R>, name: string, pivotHandler: Route | undefined, contexts?: ModelFor<R>[], queryParams?: Dict<unknown>, data?: object);
        applyToState(oldState: TransitionState<R>, isIntermediate: boolean): TransitionState<R>;
        applyToHandlers(oldState: TransitionState<R>, parsedHandlers: ParsedHandler[], targetRouteName: string, isIntermediate: boolean, checkingIfActive: boolean): TransitionState<R>;
        invalidateChildren(handlerInfos: InternalRouteInfo<R>[], invalidateIndex: number): void;
        getHandlerInfoForDynamicSegment(name: string, names: string[], objects: ModelFor<R>[], oldHandlerInfo: InternalRouteInfo<R>, _targetRouteName: string, i: number): UnresolvedRouteInfoByObject<R>;
        createParamHandlerInfo(name: string, names: string[], objects: unknown[], oldHandlerInfo: InternalRouteInfo<R>): UnresolvedRouteInfoByParam<R>;
    }
}