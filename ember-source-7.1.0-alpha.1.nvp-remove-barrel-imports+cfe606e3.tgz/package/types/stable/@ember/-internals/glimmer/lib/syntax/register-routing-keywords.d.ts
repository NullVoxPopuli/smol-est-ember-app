declare module '@ember/-internals/glimmer/lib/syntax/register-routing-keywords' {
    export {};
}