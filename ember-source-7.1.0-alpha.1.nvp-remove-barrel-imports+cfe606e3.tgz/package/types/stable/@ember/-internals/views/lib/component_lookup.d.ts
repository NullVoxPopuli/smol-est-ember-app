declare module '@ember/-internals/views/lib/component_lookup' {
    import type { InternalOwner, RegisterOptions } from "@ember/-internals/owner";
    import EmberObject from "@ember/object";
    export default class ComponentLookup extends EmberObject {
        componentFor(name: string, owner: InternalOwner): import("@ember/owner").FactoryManager<object> | undefined;
        layoutFor(name: string, owner: InternalOwner, options: RegisterOptions): unknown;
    }
}