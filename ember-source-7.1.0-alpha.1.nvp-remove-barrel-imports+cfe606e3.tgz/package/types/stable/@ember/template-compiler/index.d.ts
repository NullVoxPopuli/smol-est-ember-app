declare module '@ember/template-compiler' {
    export * from "@ember/template-compiler/lib/public-api";
    export { ALLOWED_GLOBALS } from "@ember/template-compiler/lib/plugins/allowed-globals";
}