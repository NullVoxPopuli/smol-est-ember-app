declare module '@ember/template-compiler/-internal-primitives' {
    export * from "@ember/template-compiler/lib/-internal/primitives";
}