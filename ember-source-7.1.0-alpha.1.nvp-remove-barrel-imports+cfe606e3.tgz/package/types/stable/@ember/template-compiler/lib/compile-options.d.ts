declare module '@ember/template-compiler/lib/compile-options' {
    import type { EmberPrecompileOptions } from "@ember/template-compiler/lib/types";
    /**
     * The variable name used to inject the keywords object into the
     * template's evaluation scope. auto-import-builtins rewrites bare
     * keyword references (e.g. `on`) to property accesses on this
     * variable (e.g. `__ember_keywords__.on`).
     */
    export const RUNTIME_KEYWORDS_NAME = "__ember_keywords__";
    export const keywords: Record<string, unknown>;
    export default function compileOptions(_options?: Partial<EmberPrecompileOptions>): EmberPrecompileOptions;
}