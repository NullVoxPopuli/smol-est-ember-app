declare module '@ember/routing' {
    export { default as LinkTo } from "@ember/-internals/glimmer/lib/components/link-to";
}