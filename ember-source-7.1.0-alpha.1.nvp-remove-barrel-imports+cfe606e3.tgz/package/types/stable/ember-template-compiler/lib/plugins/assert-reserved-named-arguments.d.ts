declare module 'ember-template-compiler/lib/plugins/assert-reserved-named-arguments' {
    import type { ASTPluginBuilder } from "@glimmer/syntax";
    const _default: ASTPluginBuilder;
    export default _default;
}