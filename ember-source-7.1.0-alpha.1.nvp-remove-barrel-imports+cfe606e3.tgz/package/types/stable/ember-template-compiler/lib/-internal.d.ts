declare module 'ember-template-compiler/lib/-internal' {
    export { INTERNAL_PLUGINS } from "@ember/template-compiler/-internal-primitives";
}