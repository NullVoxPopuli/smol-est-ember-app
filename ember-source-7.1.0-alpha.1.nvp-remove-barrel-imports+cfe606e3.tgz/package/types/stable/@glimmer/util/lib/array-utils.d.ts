declare module '@glimmer/util/lib/array-utils' {
    export const EMPTY_ARRAY: readonly unknown[];
    export function emptyArray<T>(): T[];
    export const EMPTY_STRING_ARRAY: string[];
    export const EMPTY_NUMBER_ARRAY: number[];
    /**
     * This function returns `true` if the input array is the special empty array sentinel,
     * which is sometimes used for optimizations.
     */
    export function isEmptyArray(input: unknown[] | readonly unknown[]): boolean;
    export function reverse<T>(input: T[]): IterableIterator<T>;
    export function enumerate<T>(input: Iterable<T>): IterableIterator<[number, T]>;
    type ZipEntry<T extends readonly unknown[]> = {
        [P in keyof T]: P extends `${infer N extends number}` ? [N, T[P], T[P]] : never;
    }[keyof T & number];
    /**
     * Zip two tuples with the same type and number of elements.
     */
    export function zipTuples<T extends readonly unknown[]>(left: T, right: T): IterableIterator<ZipEntry<T>>;
    export function zipArrays<T>(left: T[], right: T[]): IterableIterator<[
        "retain",
        number,
        T,
        T
    ] | ["pop", number, T, undefined] | ["push", number, undefined, T]>;
    export {};
}