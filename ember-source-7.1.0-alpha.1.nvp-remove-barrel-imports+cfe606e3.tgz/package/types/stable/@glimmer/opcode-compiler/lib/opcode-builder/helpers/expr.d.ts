declare module '@glimmer/opcode-compiler/lib/opcode-builder/helpers/expr' {
    import type { WireFormat } from "@glimmer/interfaces";
    import type { PushExpressionOp } from "@glimmer/opcode-compiler/lib/syntax/compilers";
    export function expr(op: PushExpressionOp, expression: WireFormat.Expression): void;
}