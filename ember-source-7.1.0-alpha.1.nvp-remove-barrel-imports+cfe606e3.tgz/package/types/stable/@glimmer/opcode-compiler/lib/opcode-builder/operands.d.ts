declare module '@glimmer/opcode-compiler/lib/opcode-builder/operands' {
    import type { BlockOperand, CompilableTemplate, DebugSymbolsOperand, IsStrictModeOperand, LabelOperand, LayoutOperand, NonSmallIntOperand, SerializedBlock, SerializedInlineBlock, StdLibOperand, SymbolTable, SymbolTableOperand } from "@glimmer/interfaces";
    export const HighLevelOperands: {
        readonly Label: 1;
        readonly IsStrictMode: 2;
        readonly DebugSymbols: 3;
        readonly Block: 4;
        readonly StdLib: 5;
        readonly NonSmallInt: 6;
        readonly SymbolTable: 7;
        readonly Layout: 8;
    };
    export function labelOperand(value: string): LabelOperand;
    export function debugSymbolsOperand(
        locals: Record<string, number>,
        upvars: Record<string, number>,
        lexical: Record<string, number>
    ): DebugSymbolsOperand;
    export function isStrictMode(): IsStrictModeOperand;
    export function blockOperand(value: SerializedInlineBlock | SerializedBlock): BlockOperand;
    export function stdlibOperand(
        value: "main" | "trusting-append" | "cautious-append" | "trusting-non-dynamic-append" | "cautious-non-dynamic-append"
    ): StdLibOperand;
    export function nonSmallIntOperand(value: number): NonSmallIntOperand;
    export function symbolTableOperand(value: SymbolTable): SymbolTableOperand;
    export function layoutOperand(value: CompilableTemplate): LayoutOperand;
}