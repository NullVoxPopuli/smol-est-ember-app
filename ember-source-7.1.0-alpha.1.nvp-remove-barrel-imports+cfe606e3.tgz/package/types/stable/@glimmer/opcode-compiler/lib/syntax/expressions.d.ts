declare module '@glimmer/opcode-compiler/lib/syntax/expressions' {
    import type { PushExpressionOp } from "@glimmer/opcode-compiler/lib/syntax/compilers";
    import { Compilers } from "@glimmer/opcode-compiler/lib/syntax/compilers";
    export const EXPRESSIONS: Compilers<PushExpressionOp, 32 | 50 | 30 | 39 | 35 | 37 | 38 | 31 | 53 | 29 | 48 | 49 | 28 | 27 | 52 | 51 | 54>;
}