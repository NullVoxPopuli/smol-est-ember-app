declare module '@glimmer/interfaces/lib/managers/internal/helper' {
    import type { Helper, HelperDefinitionState, Owner } from "@glimmer/interfaces/lib/runtime.js";
    import type { HelperManager } from "@glimmer/interfaces/lib/managers/helper.js";

    export interface InternalHelperManager<TOwner extends Owner> {
      getDelegateFor(owner: TOwner | undefined): HelperManager<unknown>;

      getHelper(definition: HelperDefinitionState): Helper;
    }
}