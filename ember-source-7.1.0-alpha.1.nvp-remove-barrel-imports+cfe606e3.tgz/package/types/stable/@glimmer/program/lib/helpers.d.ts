declare module '@glimmer/program/lib/helpers' {
    import type { RuntimeArtifacts } from "@glimmer/interfaces";
    export function artifacts(): RuntimeArtifacts;
}