declare module '@glimmer/compiler/lib/passes/1-normalization' {
    import type * as ASTv2 from "@glimmer/syntax/lib/v2/api";
    import type * as src from "@glimmer/syntax/lib/source/api";
    import type { Result } from "@glimmer/compiler/shared/result";
    import * as mir from "@glimmer/compiler/lib/2-encoding/mir";
    /**
     * Normalize the AST from @glimmer/syntax into the HIR. The HIR has special
     * instructions for keywords like `{{yield}}`, `(has-block)` and
     * `{{#in-element}}`.
     *
     * Most importantly, it also classifies HTML element syntax into:
     *
     * 1. simple HTML element (with optional splattributes)
     * 2. component invocation
     *
     * Because the @glimmer/syntax AST gives us a string for an element's tag,
     * this pass also normalizes that string into an expression.
     *
     * ```
     * // normalized into a path expression whose head is `this` and tail is
     * // `["x"]`
     * <this.x />
     *
     * {{#let expr as |t|}}
     *   // `"t"` is normalized into a variable lookup.
     *   <t />
     *
     *   // normalized into a path expression whose head is the variable lookup
     *   // `t` and tail is `["input"]`.
     *   <t.input />
     * {{/let}}
     *
     * // normalized into a free variable lookup for `SomeComponent` (with the
     * // context `ComponentHead`).
     * <SomeComponent />
     *
     * // normalized into a path expression whose head is the free variable
     * // `notInScope` (with the context `Expression`), and whose tail is
     * // `["SomeComponent"]`. In resolver mode, this path will be rejected later,
     * // since it cannot serve as an input to the resolver.
     * <notInScope.SomeComponent />
     * ```
     */
    export default function normalize(source: src.Source, root: ASTv2.Template, isStrict: boolean): Result<mir.Template>;
}