declare module '@glimmer/compiler/lib/passes/2-encoding' {
    import type { WireFormat } from "@glimmer/interfaces";
    import type * as mir from "@glimmer/compiler/lib/passes/2-encoding/mir";
    export function visit(template: mir.Template): WireFormat.SerializedTemplateBlock;
}